define( {
	// Generic.
	OK:     "OK",
	CANCEL: "Cancelar",
	RESET:  "Restablecer",
	
	// Menu.
	MENU_ON_SAVE:   "Prefixo automático ó gardar",
	MENU_SELECTION: "Prefixo automático na selección",
	MENU_SETTINGS:  "Axustes de Autoprefixer...",
	
	// Settings dialog.
	SETTINGS_TITLE:          "Axustes de Autoprefixer",
	SETTINGS_VISUAL_CASCADE: "Cascada visual",
	SETTINGS_BROWSERS:       "Navegadores"
} );
