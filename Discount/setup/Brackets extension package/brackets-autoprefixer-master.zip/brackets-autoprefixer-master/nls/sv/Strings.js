define( {
	// Generic.
	OK:     "OK",
	CANCEL: "Avbryt",
	RESET:  "Återställ",
	
	// Menu.
	MENU_ON_SAVE:    "Lägg till prefix vid spara",
	MENU_SELECTION:  "Lägg till prefix på markering",
	MENU_SETTINGS:   "Inställningar för Autoprefixer...",
	
	// Settings dialog.
	SETTINGS_TITLE:          "Inställningar för Autoprefixer",
	SETTINGS_VISUAL_CASCADE: "Visuell prefixordning",
	SETTINGS_BROWSERS:       "Webbläsare"
} );