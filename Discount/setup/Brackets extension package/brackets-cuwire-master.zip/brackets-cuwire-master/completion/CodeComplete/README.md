sample taken from: https://github.com/sabottenda/libclang-sample
