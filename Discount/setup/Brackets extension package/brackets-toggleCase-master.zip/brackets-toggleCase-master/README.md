# ToggleCase
Use the shortcut `Alt-Shift` to toggle the case of the current word.

For example you are writing a text and you started your word with a lowercase letter but it must be uppercase.
The normal way would be some stuff like `Ctrl-Left` and then changing the first letter. With `ToggleCase` you can use `Alt-Shift`.
